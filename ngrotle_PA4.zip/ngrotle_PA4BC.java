package ngrotle_PA4;

import java.io.File;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/* Programmer: Nic Grotle
 * CS 2300
 * 4/12/22
 */

public class ngrotle_PA4BC {
	
	public static void main(String[] args) throws FileNotFoundException {
		Matrix mat=new Matrix("input_1.txt");
		
		System.out.println("Part B and C:");
		System.out.println("\nFirst row is parrallel projection points, second row is perspective projection points, third row is distance then repeats itself\n");
		
		partB(mat);
		partC(mat);
		
	}//end of main

	
	public static void partB(Matrix matrix) {
		Vector vector=new Vector();
		double[] q =new double[3];
		//point on plane
		q[0]=matrix.get(1, 1);
		q[1]=matrix.get(1,2);
		q[2]=matrix.get(1, 3);
		
		
		// vector normal to plane
		double[] n =new double[3];
		n[0]=matrix.get(1, 4);
		n[1]=matrix.get(1, 5);
		n[2]=matrix.get(1, 6);
		
		//the parallel projection
		double[] v =new double[3];
		v[0]=matrix.get(1, 7);
		v[1]=matrix.get(1, 8);
		v[2]=matrix.get(1, 9);
		
		double[] x =new double[3];
		double[] x_ = new double[3];
		double[] qMinusX = new double[3];
		double distance;
		for(int r=1;r<10;r++) {
			for(int i=1;i<9;i=i+3) {
				//the points to be projected onto plane
				x[0]=matrix.get(r, i);
				x[1]=matrix.get(r, i+1);
				x[2]=matrix.get(r, i+2);
				qMinusX=vector.subtract(q,x);
				//x′ = x + [([q - x]·n)/v·n]v
				//calculation for parrallel projection
				x_[0]=x[0]+((vector.dot(qMinusX,n)/vector.dot(v, n)))*v[0];
				x_[1]=x[1]+((vector.dot(qMinusX,n)/vector.dot(v, n)))*v[1];
				x_[2]=x[2]+((vector.dot(qMinusX,n)/vector.dot(v, n)))*v[2];
				System.out.println(+x_[0]+", "+x_[1]+", "+x_[2] );
				
	
				//x′ = [q·n/x·n]x
				//perspective projection calculation
				x_[0]=(vector.dot(q,n)/vector.dot(x,n) )*x[0];
				x_[1]=(vector.dot(q,n)/vector.dot(x,n) )*x[1];
				x_[2]=(vector.dot(q,n)/vector.dot(x,n) )*x[2];
				System.out.println(+x_[0]+", "+x_[1]+", "+x_[2] );
				
				
				
				//d = (c + n·x)/n·n
				//where c = -n·q
				//distance from point to plane calculation
				distance = (vector.dot(vector.negative(n), q) +vector.dot(n, x))/(vector.dot(n, n));
				System.out.println( +distance +"\n");
				
			
			}
		}//end of nested for loop	
	}//end of part B
	
	public static void partC(Matrix matrix) {
	
		Vector vector=new Vector();
		double[] x =new double[3];
		double[] y =new double[3];
		double[] v =new double[3];
		double[] p1 =new double[3];
		double[] p2 =new double[3];
		double[] p3 =new double[3];
		double[] w =new double[3];
		double[] z =new double[3];
		double[] abc=new double[3];
		double[] intersection=new double[3];
		double[] u1u2t=new double[3];
		double[] minusV = new double[3];
		double[][] inverseMatrix= new double[3][3];
		x[0]=matrix.get(1, 1);
		x[1]=matrix.get(1, 2);
		x[2]=matrix.get(1, 3);
		y[0]=matrix.get(1, 4);
		y[1]=matrix.get(1, 5);
		y[2]=matrix.get(1, 6);
		v=vector.subtract(y, x);
		minusV=vector.negative(v);
		
		//collects all the points of the triangles.
		for(int col =2;col<10;col++) {
			p1[0]=matrix.get(col, 1);
			p1[1]=matrix.get(col, 2);
			p1[2]=matrix.get(col, 3);
			p2[0]=matrix.get(col, 4);
			p2[1]=matrix.get(col, 5);
			p2[2]=matrix.get(col, 6);
			p3[0]=matrix.get(col, 7);
			p3[1]=matrix.get(col, 8);
			p3[2]=matrix.get(col, 9);
			
			
			
			w=vector.subtract(p2, p1);
			z=vector.subtract(p3, p1);
			
			//a = x1 - p1 , b = x2 - p2 ,  c = x3 - p3
			//intersection between line and triangle
			abc=vector.subtract(x, p1);
			inverseMatrix = matrix.inverseCalc(w,z,minusV);
			u1u2t=matrix.matrixVectorMultiply(inverseMatrix, abc);
			
			
			if((u1u2t[0]>0)&&(u1u2t[0]<1)&&(u1u2t[1]>0)&&(u1u2t[1]<1)&&(u1u2t[0]+u1u2t[1]<1) ) {
				intersection = vector.addVectors(	vector.scale(u1u2t[2], v)	,x	);

				System.out.println("intersects at "+intersection[0]+", "+intersection[1]+", "+intersection[2]+", ");
			}
			
			System.out.println("Does not intersect");
			
		}
			
	}//end of partC()
}//end of class


class Matrix{
	
	public double get(int r,int c) {
		return matrix[r-1][c-1];
	}
	
	//a method to calculate the determinate of a matrix made by 3 vectors
	public double by3determinate(double a[], double b[], double c[]) {
		double determinate=a[0]*(b[1]*c[2]-b[2]*c[1])-b[0]*(a[1]*c[2]-a[2]*c[1])+c[0]*(a[1]*b[2]-b[1]*a[2]);
		
		return determinate;
	}
	
	//a method to find the inverse matrix
	public double[][] inverseCalc(double a[], double b[], double c[]){
		double[][] adj= new double[3][3];
		
		//calculates the determinate
		double detetminate=by3determinate(a,b,c);
		
		
		if(detetminate!=0) {
			adj[0][0]= (a[0]*b[1]-a[1]*b[0])*(1/detetminate);
			adj[1][0]=-(a[1]*b[2]-a[2]*b[1])*(1/detetminate);
			adj[2][0]=-(a[2]*b[0]-a[0]*b[2])*(1/detetminate);
			
			adj[0][1]=-(b[0]*c[1]-b[1]*c[0])*(1/detetminate);
			adj[1][1]= (b[1]*c[2]-b[2]*c[1])*(1/detetminate);
			adj[2][1]= (b[2]*c[0]-b[0]*c[2])*(1/detetminate);
			
			adj[0][2]= (c[0]*a[1]-c[1]*a[0])*(1/detetminate);
			adj[1][2]=-(c[1]*a[2]-c[2]*a[1])*(1/detetminate);
			adj[2][2]= (c[2]*a[0]-c[0]*a[2])*(1/detetminate);	
		}
		return adj;
	}
	//a method for multiplying a matrix by a vector
	public double[] matrixVectorMultiply(double matrix[][],double v[]){
	double[] product = new double[3];//holds the product of the multiplication
	product[0]=matrix[0][0]*v[0]+matrix[0][1]*v[1]+matrix[0][2]*v[2];
	product[1]=matrix[1][0]*v[0]+matrix[1][1]*v[1]+matrix[1][2]*v[2];
	product[2]=matrix[2][0]*v[0]+matrix[2][1]*v[1]+matrix[2][2]*v[2];
	
	return product;
	}
	
	
	double[][] matrix= new double[10][10];
	//reads the file
		public Matrix(String location) throws FileNotFoundException {
			File fileName = new File(location);
			Scanner readFile = new Scanner(fileName);	
			int r=0;
			while(readFile.hasNextDouble()) {
				for(int c=0;c<9;c++) {
				this.matrix[r][c]=readFile.nextDouble();
				}
				r++;
			}
			readFile.close();
		}
	
}//end of matrix

class Vector{
	public double[] cross(double a1,double a2,double a3,double b1,double b2, double b3) {
		double product[]=new double[3];
		product[0]=a2*b3-a3*b2;
		product[1]=a3*b1-a1*b3;
		product[2]=a1*b2-a2*b1;
		return product;
		
	}//cross product
	public double[] negative(double[] a) {
		a[0]=-a[0];
		a[1]=-a[1];
		a[2]=-a[2];
		return a;
	}
	public double length(double a1,double a2,double a3) {
		double length=a1*a1+a2*a2+a3*a3;
		length=Math.sqrt(length);
		return length;
	}
	public double length(double a[]) {
		double length=a[0]*a[0]+a[1]*a[1]+a[2]*a[2];
		length=Math.sqrt(length);
		return length;
	}
	//a method to scale a vector by a constant
	public double[] scale(double sclaingFactor,double[] a) {
		a[0]=a[0]*sclaingFactor;
		a[1]=a[1]*sclaingFactor;
		a[2]=a[2]*sclaingFactor;
		return a;
	}
	
	public double[] addVectors(double[] b ,double[] a) {
		a[0]=a[0]+b[0];
		a[1]=a[1]+b[1];
		a[2]=a[2]+b[2];
		return a;
	}
	
	
	
	//subtracts two vectors
	public double[] subtract(double a[],double b[]) {
		double unit[]=new double[3];
		unit[0]=a[0]-b[0];
		unit[1]=a[1]-b[1];
		unit[2]=a[2]-b[2];
		return unit;
	}
	//vector unit length and gets 3 coordinates
	public double[] makeUnit(double a1,double a2,double a3) {
		double unit[]=new double[3];
		double l=length(a1,a2,a3);
		unit[0]=a1/l;
		unit[1]=a2/l;
		unit[2]=a2/l;
		return unit;
		
	}
	
	// for a single vector
	public double[] makeUnit(double a[]) {
		double unit[]=new double[3];
		double len=length(a[0],a[1],a[2]);
		unit[0]=a[0]/len;
		unit[1]=a[1]/len;
		unit[2]=a[2]/len;
		return unit;
		
	}
	public double dot(double[] vectorA,double[] vectorB) {
		return vectorA[0]*vectorB[0]+vectorA[1]*vectorB[1]+vectorA[2]*vectorB[2];
	}
}//vector