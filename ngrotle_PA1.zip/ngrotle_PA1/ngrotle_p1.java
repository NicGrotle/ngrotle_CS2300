package ngrotle_PA1;

import java.io.FileWriter;
import java.io.IOException;

/* Programmer: Nic Grotle
 * CS 2300
 * 2/2/22
 */

public class ngrotle_p1 
{
	
	public static void main(String[] args) throws IOException
	{
		int letFirstName = 3;//letters in first name
		int letLastName = 6;//letters in last name
		
		Matrices p1_Mat1 = new Matrices(letFirstName, letLastName,1);
		p1_Mat1.incrementValues(1);//add 1 to each value
		p1_Mat1.writeTOFile("ngrotle_mat1.txt");
	//mat 1
		Matrices p1_Mat2 = new Matrices(letFirstName,letLastName,2);
		p1_Mat2.incrementValuesColFirst(3);//add 3 to each value
		p1_Mat2.writeTOFile("ngrotle_mat2.txt");
	//mat 2	
		Matrices p1_Mat3 = new Matrices(letFirstName , letLastName , 0.4f);//start at 0.4
		p1_Mat3.incrementDecimalValues(0.3f);//add 0.3 every number
		p1_Mat3.writeTOFileDecimal("ngrotle_mat3.txt");
	//mat 3	
		Matrices p1_Mat4 = new Matrices(6,13,2);//6 rows, 13 columns starting at 2
		p1_Mat4.incrementValuesColFirst(2); //adding 2
		p1_Mat4.writeTOFile("ngrotle_mat4.txt");
	//mat 4	
		Matrices p1_Mat5 = new Matrices(6,13,-7);
		p1_Mat5.incrementValues(1);
		p1_Mat5.writeTOFile("ngrotle_mat5.txt");
	//mat 5
	
	}//end of main

}//end class ngrotle_p1

class Matrices
{
	private int [][] matrices;
	private float[][] decMatrices;
	private int numOfRow, numOfCol, startValue;
	float startDecimalValue;
	
	
	public Matrices(int numOfRow, int numOfCol, int startValue)
	{
		this.numOfRow = numOfRow;
		this.numOfCol = numOfCol;
		this.startValue = startValue;
		matrices = new int[numOfRow][numOfCol];
	}
	
	public Matrices(int numOfRow, int numOfCol, float startDecimalValue)
	{
		this.numOfRow = numOfRow;
		this.numOfCol = numOfCol;
		this.startDecimalValue = (float)startDecimalValue;
		decMatrices = new float[numOfRow][numOfCol];
	}
	
	public double startingDecIndex()
	{
		return startDecimalValue;
	}
	
	public int startingIndex()
	{
		return startValue;
	}
	
	
	
	public void  incrementDecimalValues(float incDecValue )
	{
		float previous = 0;
		
		for(int row = 0 ; row < numOfRow; row++)
		{
			for (int col = 0 ; col < numOfCol ; col++)
			{ 
				
				decMatrices[row][col] =(float)((previous + incDecValue));
				decMatrices[0][0] = (float) startingDecIndex();
				previous = decMatrices[row][col] ;
				
			}// col- for loop
			
		}// row- for loop
	}//iterate each number through a float
	
	public void  incrementValues(int incValue )
	{
		int previous = 0;
		
		for(int row = 0 ; row < numOfRow; row++)
		{
			for (int col = 0 ; col < numOfCol ; col++)
			{ 
				
				matrices[row][col] = previous + incValue;
				matrices[0][0] = (int) startingIndex();
				previous = matrices[row][col] ;
				
			}// col- for loop
			
		}// row- for loop
	}//iterate columns then rows
	
	public void  incrementValuesColFirst(int incValue )
	{
		int previous = 0;
		
		for(int col = 0 ; col < numOfCol; col++)
		{
			for (int row = 0 ; row < numOfRow ; row++)
			{ 
				
				matrices[row][col] = previous + incValue;
				matrices[0][0] = (int) startingIndex();
				previous = matrices[row][col] ;
				
			}// col- for loop
			
		}// row- for loop
	}//increment rows then columns
	
	 
	public void writeTOFile(String fileName) throws IOException
	{
		
		FileWriter mat1 = new FileWriter(fileName);
		for(int row = 0 ; row < numOfRow; row++)
		{
			for (int col = 0 ; col < numOfCol ; col++)
			{
				mat1.write(matrices[row][col] + " ");
				
			}// col- for loop
			mat1.write("\n");

		}// row- for loop
		
		mat1.close();
	}//write to a file int
	
	public void writeTOFileDecimal(String fileName) throws IOException
	{
		
		FileWriter mat1 = new FileWriter(fileName);
		
		for(int row = 0 ; row < numOfRow; row++)
		{
			for (int col = 0 ; col < numOfCol ; col++)
			{
				mat1.write((  decMatrices[row][col]) + " " );
				
			}// col- for loop
			mat1.write("\n");

		}// row- for loop
		
		mat1.close();
	}//write to a file in decimal
}// end of class Matrices