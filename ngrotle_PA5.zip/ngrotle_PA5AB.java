package ngrotle_PA5;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.math.*;


/* Programmer: Nic Grotle
 * CS 2300
 * 5/4/22
 */

public class ngrotle_PA5AB {

	public static void main(String[] args) throws FileNotFoundException {
		//Part A
		//saves file as a matrix
		Matrix matrixA = new Matrix("Input_A.txt");
		
		
		
		System.out.println("Part A:");
		
		//invalid if not stochastic
		if (matrixA.stochastic() != true) {
			System.out.println("Invalid Input");
		} 
		else {
			//this calls the method to calculate the power algorithim
			double[] eigenVector = matrixA.powerAlgorithm();
			double biggest = 0;
			int index = 0;
			double big = 0;
	
			
			//eigenvector for the web pages
			for (int i = 0; i < eigenVector.length; i++) {
				System.out.println(String.format("%.3f", eigenVector[i]));
				if (eigenVector[i] > biggest) {
					biggest = eigenVector[i];
					index = i;
				}
			}

			//rank order of web pages
			System.out.print((index + 1) + " ");
			for (int i = 0; i < eigenVector.length - 1; i++) {
				for (int j = 0; j < eigenVector.length; j++) {
					if (eigenVector[j] < biggest && eigenVector[j] > big) {
						big = eigenVector[j];
						index = j;
					}
				}
				System.out.print((index + 1) + " ");
				biggest = big;
				big = 0;
			}
		} //end of A
		
		//the start of part B
		System.out.println("\n\nPart B:");

		LinearBinaryClassification classifier = new LinearBinaryClassification();
		//this reads the file
		String location = "training_input_B.txt";
		File fileName = new File(location);
		Scanner readFile = new Scanner(fileName);
		double[][] trainingMatrix = new double[5][6];
		double[] labels=new double[5];
		for (int c = 0; c < 5; c++) {
			labels[c]=readFile.nextDouble();
			for (int v = 0; v < 5; v++) {
				trainingMatrix[c][v] = readFile.nextDouble();
			}
		}
		readFile.close();
		
		//this trains the weights
		double[] weights=classifier.findWeights(trainingMatrix,labels);

		//this reads the file to be tested
		location = "test_input_B.txt";
		fileName = new File(location);
		readFile = new Scanner(fileName);
		double[][] analysisMatrix = new double[5][5];
		
		for (int c = 0; c < 5; c++) {
			for (int v = 0; v < 5; v++) {
				analysisMatrix[c][v] = readFile.nextDouble();
			}
		}
		readFile.close();
		
		//and this classifies the new data 
		classifier.applyWeights(analysisMatrix,weights);

	}// end of main()

}// end of class

//this class holds the matrix and the methods to perform the power algorithm 
class Matrix {
	double[][] matrix = new double[10][10];

	// this constructor reads the file
	public Matrix(String location) throws FileNotFoundException {
		File fileName = new File(location);
		Scanner readFile = new Scanner(fileName);
		int r = 0;
		while (readFile.hasNextDouble()) {
			for (int c = 0; c < 10; c++) {
				this.matrix[r][c] = readFile.nextDouble();
			}
			r++;
		}
		readFile.close();
	}

	//this methods tests is a matrix is stochastic
	public boolean stochastic() {
		double columnSum;

		for (int c = 0; c < 10; c++) {
			columnSum = 0;
			for (int r = 0; r < 10; r++) {
				columnSum += matrix[r][c];
				if (matrix[r][c] < 0) {
					return false;
				}
			}
			if (Math.abs(columnSum - 1) > 0.0001) {
				System.out.println(Math.abs(columnSum - 1));
				return false;
			}
		}
		return true;
	}// end of stochastic()

	//power algorithm calculations
	public double[] powerAlgorithm() {
		double x[] = { 1, 12, 1, 1, 1, 1, 1, 25, 1, 1 };
		double j;
		for (int k = 0; k <= 40; k++) {
			//this calls a method to multiply the matricies
			x = matrixVectorMultiply(x);
			
			//finds the largest number in the vector
			j = infinateMag(x);
			
			//this tests if converged to zero
			if (Math.abs(j) < .0001) {
				System.out.println("has a zero eigenvector");
				x[1] = 5;
			}
			for (int i = 0; i < x.length; i++) {
				x[i] = x[i] / j;
			}
		}

		return x;
	}// end of powerAlgorithm
	//this multiplies a matrix by a vector and outputs a vector
			public double[] matrixVectorMultiply(double[] vector) {
				double[] newVector = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
				for (int r = 0; r < 10; r++) {
					for (int c = 0; c < 10; c++) {
						newVector[c] += matrix[c][r] * vector[r];
					}
				}
				return newVector;
			}
	
	//this finds the largest number in a vector
	public double infinateMag(double[] vector) {
		double largest = 0;
		for (int i = 0; i < vector.length; i++) {
			if (Math.abs(vector[i]) > largest) {
				largest = Math.abs(vector[i]);
			}
		}
		
		return largest;
	}
}

//this class holds methods to do linear Binary classification
class LinearBinaryClassification {

	//this method finds dot products
	public double dotProduct(double[] vector1, double[] vector2) {
		double dotProduct = 0;
		for (int i = 0; i < vector1.length; i++) {
			dotProduct += vector1[i] * vector2[i];
		}
		return dotProduct;
	}

	//scales vector and adds to vector
	public double[] addScaleVectors(double[] vector1, double[] vector2, double scale) {
		double[] sum = new double[vector1.length];

		for (int i = 0; i < vector1.length; i++) {
			sum[i] = vector1[i] + scale * vector2[i];
		}
		return sum;
	}

	//this finds the weights
	public double[] findWeights(double[][] featuresMatrix,double[] labels) {
		double[] weights = { 5, 6, 4, 3, 4 };
		double[] features = new double[5];
		double F;
		double error = 0;

		// e=Y1-f(W,X1)
		// W = W + eX1
		for (int j = 0; j < 10; j++) {
			for (int i = 0; i < 5; i++) {
				features = makeIntoVector(i, featuresMatrix);
				if (dotProduct(weights, features) >= 0) {
					F = 1;
				} else {
					F = 0;
				}
				error = labels[0] - F;
				weights = addScaleVectors(weights, features, error);
			}	
		}
		printVector(weights);
		return weights;
	}

	//this method prints vectors
	public void printVector(double[] vector) {
		for (int i = 0; i < vector.length; i++) {
			System.out.print(vector[i] + " ");
		}
		System.out.println();
	}
	//this makes a row from a matrix into a vector
	public double[] makeIntoVector(int row, double[][] matrix) {
		int length=matrix[0].length;
		
		double[] vector = new double[length];
		for (int i = 0; i < length; i++) {
			vector[i] = matrix[row][i];
			
		}
		return vector;
	}// end of printVector

	//this takes in a matrix and applies the weights 
	public void applyWeights(double[][] matrix,double[]weight) {
		double[] vector;
		for(int i=0;i<5;i++) {
			vector=makeIntoVector(i,matrix);
			
			if(dotProduct(vector,weight)>=0) {
				System.out.print("1 ");
			}
			else {
				System.out.print("0 ");
			}
		}
	}
}// end of LinearBinaryClassification